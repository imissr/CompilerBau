#pragma once

#include "ccn/phase_driver.h"
#include "ccn/dynamic_core.h"
