#pragma once

#include <stdio.h>
#include "palm/hash_table.h"

typedef FILE* fileptr;
typedef htable_st* htable_stptr;
