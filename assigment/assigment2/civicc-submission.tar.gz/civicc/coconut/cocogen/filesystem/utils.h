#pragma once

char *FSdirifyString(char *path);
