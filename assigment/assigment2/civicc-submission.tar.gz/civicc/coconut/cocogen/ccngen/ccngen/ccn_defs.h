#pragma once
#define CCN_USES_UNSAFE true
