#pragma once
bool backendIsStatic();
bool backendIsDynamic();
