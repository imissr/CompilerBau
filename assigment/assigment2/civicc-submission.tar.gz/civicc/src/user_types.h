#pragma once

#include "palm/hash_table.h"

typedef htable_st* htable_stptr;
// Add more types here if necessary
